package sql;

public class Table {


}
