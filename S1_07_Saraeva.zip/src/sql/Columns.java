package sql;

public class Columns {

    Columns (Object[] name){

    }
}
